﻿namespace DemoLINQ
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.открытьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запросыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запрос1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запрос2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запрос3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запрос4ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запрос5ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запрос6ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запрос7ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запрос8ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запрос9ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запрос10ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.справкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оПрограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.splitContainer2);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.dataGridView3);
            this.splitContainer1.Size = new System.Drawing.Size(775, 437);
            this.splitContainer1.SplitterDistance = 311;
            this.splitContainer1.TabIndex = 0;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.dataGridView1);
            this.splitContainer2.Panel1.Controls.Add(this.menuStrip1);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.dataGridView2);
            this.splitContainer2.Size = new System.Drawing.Size(775, 311);
            this.splitContainer2.SplitterDistance = 173;
            this.splitContainer2.TabIndex = 0;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 24);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(775, 149);
            this.dataGridView1.TabIndex = 0;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.запросыToolStripMenuItem,
            this.справкаToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(775, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.открытьToolStripMenuItem,
            this.toolStripSeparator1,
            this.выходToolStripMenuItem});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.файлToolStripMenuItem.Text = "Файл";
            // 
            // открытьToolStripMenuItem
            // 
            this.открытьToolStripMenuItem.Enabled = false;
            this.открытьToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("открытьToolStripMenuItem.Image")));
            this.открытьToolStripMenuItem.Name = "открытьToolStripMenuItem";
            this.открытьToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.открытьToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.открытьToolStripMenuItem.Text = "Открыть";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(161, 6);
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("выходToolStripMenuItem.Image")));
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.выходToolStripMenuItem.Text = "Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.выходToolStripMenuItem_Click);
            // 
            // запросыToolStripMenuItem
            // 
            this.запросыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.запрос1ToolStripMenuItem,
            this.запрос2ToolStripMenuItem,
            this.запрос3ToolStripMenuItem,
            this.запрос4ToolStripMenuItem,
            this.запрос5ToolStripMenuItem,
            this.запрос6ToolStripMenuItem,
            this.запрос7ToolStripMenuItem,
            this.запрос8ToolStripMenuItem,
            this.запрос9ToolStripMenuItem,
            this.запрос10ToolStripMenuItem});
            this.запросыToolStripMenuItem.Name = "запросыToolStripMenuItem";
            this.запросыToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.запросыToolStripMenuItem.Text = "Запросы";
            // 
            // запрос1ToolStripMenuItem
            // 
            this.запрос1ToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("запрос1ToolStripMenuItem.Image")));
            this.запрос1ToolStripMenuItem.Name = "запрос1ToolStripMenuItem";
            this.запрос1ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Shift | System.Windows.Forms.Keys.F1)));
            this.запрос1ToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.запрос1ToolStripMenuItem.Text = "Запрос 1";
            this.запрос1ToolStripMenuItem.ToolTipText = "Список всех артистов, который выпустили свои альбомы после распада СССР";
            this.запрос1ToolStripMenuItem.Click += new System.EventHandler(this.запрос1ToolStripMenuItem_Click);
            // 
            // запрос2ToolStripMenuItem
            // 
            this.запрос2ToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("запрос2ToolStripMenuItem.Image")));
            this.запрос2ToolStripMenuItem.Name = "запрос2ToolStripMenuItem";
            this.запрос2ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Shift | System.Windows.Forms.Keys.F2)));
            this.запрос2ToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.запрос2ToolStripMenuItem.Text = "Запрос 2";
            this.запрос2ToolStripMenuItem.ToolTipText = "Список стран (без повторений)";
            this.запрос2ToolStripMenuItem.Click += new System.EventHandler(this.запрос2ToolStripMenuItem_Click);
            // 
            // запрос3ToolStripMenuItem
            // 
            this.запрос3ToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("запрос3ToolStripMenuItem.Image")));
            this.запрос3ToolStripMenuItem.Name = "запрос3ToolStripMenuItem";
            this.запрос3ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Shift | System.Windows.Forms.Keys.F3)));
            this.запрос3ToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.запрос3ToolStripMenuItem.Text = "Запрос 3";
            this.запрос3ToolStripMenuItem.ToolTipText = "Список наименований альбомов, выпущенных в США, упорядоченных по году выпуска";
            this.запрос3ToolStripMenuItem.Click += new System.EventHandler(this.запрос3ToolStripMenuItem_Click);
            // 
            // запрос4ToolStripMenuItem
            // 
            this.запрос4ToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("запрос4ToolStripMenuItem.Image")));
            this.запрос4ToolStripMenuItem.Name = "запрос4ToolStripMenuItem";
            this.запрос4ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Shift | System.Windows.Forms.Keys.F4)));
            this.запрос4ToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.запрос4ToolStripMenuItem.Text = "Запрос 4";
            this.запрос4ToolStripMenuItem.ToolTipText = "Суммарная стоимость альбомов за страну";
            this.запрос4ToolStripMenuItem.Click += new System.EventHandler(this.запрос4ToolStripMenuItem_Click);
            // 
            // запрос5ToolStripMenuItem
            // 
            this.запрос5ToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("запрос5ToolStripMenuItem.Image")));
            this.запрос5ToolStripMenuItem.Name = "запрос5ToolStripMenuItem";
            this.запрос5ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Shift | System.Windows.Forms.Keys.F5)));
            this.запрос5ToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.запрос5ToolStripMenuItem.Text = "Запрос 5";
            this.запрос5ToolStripMenuItem.ToolTipText = "Список: компания и количество альбомов за год, года упорядочены по возрастанию";
            this.запрос5ToolStripMenuItem.Click += new System.EventHandler(this.запрос5ToolStripMenuItem_Click);
            // 
            // запрос6ToolStripMenuItem
            // 
            this.запрос6ToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("запрос6ToolStripMenuItem.Image")));
            this.запрос6ToolStripMenuItem.Name = "запрос6ToolStripMenuItem";
            this.запрос6ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Shift | System.Windows.Forms.Keys.F6)));
            this.запрос6ToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.запрос6ToolStripMenuItem.Text = "Запрос 6";
            this.запрос6ToolStripMenuItem.ToolTipText = "Наименование альбомов и имя продюсера, получившего самое большое вознаграждение з" +
    "а вклад в развитие";
            this.запрос6ToolStripMenuItem.Click += new System.EventHandler(this.запрос6ToolStripMenuItem_Click);
            // 
            // запрос7ToolStripMenuItem
            // 
            this.запрос7ToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("запрос7ToolStripMenuItem.Image")));
            this.запрос7ToolStripMenuItem.Name = "запрос7ToolStripMenuItem";
            this.запрос7ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Shift | System.Windows.Forms.Keys.F7)));
            this.запрос7ToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.запрос7ToolStripMenuItem.Text = "Запрос 7";
            this.запрос7ToolStripMenuItem.ToolTipText = "Количество альбомов каждого продюсера в период  между годами выхода альбома 1988 " +
    "- 1990 гг";
            this.запрос7ToolStripMenuItem.Click += new System.EventHandler(this.запрос7ToolStripMenuItem_Click);
            // 
            // запрос8ToolStripMenuItem
            // 
            this.запрос8ToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("запрос8ToolStripMenuItem.Image")));
            this.запрос8ToolStripMenuItem.Name = "запрос8ToolStripMenuItem";
            this.запрос8ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Shift | System.Windows.Forms.Keys.F8)));
            this.запрос8ToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.запрос8ToolStripMenuItem.Text = "Запрос 8";
            this.запрос8ToolStripMenuItem.ToolTipText = "Фамилию продюсера получившего вознаграждение последним";
            this.запрос8ToolStripMenuItem.Click += new System.EventHandler(this.запрос8ToolStripMenuItem_Click);
            // 
            // запрос9ToolStripMenuItem
            // 
            this.запрос9ToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("запрос9ToolStripMenuItem.Image")));
            this.запрос9ToolStripMenuItem.Name = "запрос9ToolStripMenuItem";
            this.запрос9ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Shift | System.Windows.Forms.Keys.F9)));
            this.запрос9ToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.запрос9ToolStripMenuItem.Text = "Запрос 9";
            this.запрос9ToolStripMenuItem.ToolTipText = "Информацию о самом дешевом альбоме (название альбома, исполнителя и продюсера)";
            this.запрос9ToolStripMenuItem.Click += new System.EventHandler(this.запрос9ToolStripMenuItem_Click);
            // 
            // запрос10ToolStripMenuItem
            // 
            this.запрос10ToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("запрос10ToolStripMenuItem.Image")));
            this.запрос10ToolStripMenuItem.Name = "запрос10ToolStripMenuItem";
            this.запрос10ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Shift | System.Windows.Forms.Keys.F10)));
            this.запрос10ToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.запрос10ToolStripMenuItem.Text = "Запрос 10";
            this.запрос10ToolStripMenuItem.ToolTipText = "Полную информацию об альбомах, отсортированную по следующим критериям: \r\nгод выхо" +
    "да альбома, стоимость  альбома, наименование альбома";
            this.запрос10ToolStripMenuItem.Click += new System.EventHandler(this.запрос10ToolStripMenuItem_Click);
            // 
            // справкаToolStripMenuItem
            // 
            this.справкаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.оПрограммеToolStripMenuItem});
            this.справкаToolStripMenuItem.Name = "справкаToolStripMenuItem";
            this.справкаToolStripMenuItem.Size = new System.Drawing.Size(65, 20);
            this.справкаToolStripMenuItem.Text = "Справка";
            // 
            // оПрограммеToolStripMenuItem
            // 
            this.оПрограммеToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("оПрограммеToolStripMenuItem.Image")));
            this.оПрограммеToolStripMenuItem.Name = "оПрограммеToolStripMenuItem";
            this.оПрограммеToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
            this.оПрограммеToolStripMenuItem.Text = "О программе";
            this.оПрограммеToolStripMenuItem.Click += new System.EventHandler(this.оПрограммеToolStripMenuItem_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView2.Location = new System.Drawing.Point(0, 0);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(775, 134);
            this.dataGridView2.TabIndex = 0;
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView3.Location = new System.Drawing.Point(0, 0);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(775, 122);
            this.dataGridView3.TabIndex = 0;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(775, 437);
            this.Controls.Add(this.splitContainer1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Введение в LINQ";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel1.PerformLayout();
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem открытьToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запросыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запрос1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запрос2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запрос3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запрос4ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запрос5ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запрос6ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запрос7ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запрос8ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запрос9ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запрос10ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem справкаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem;


    }
}

